# ============================================================
# MILESTONE 6: Backend API Development for Anxiety Prediction
# AI-Based Exam Anxiety Detector
# ============================================================
# File: main.py  (FastAPI Backend)
#
# Activity 6.1: Selecting FastAPI for Backend Development
# Activity 6.2: Loading the Trained BERT Model
# Activity 6.3: Defining Request & Response Schema
# Activity 6.4: Implementing the Prediction Endpoint
# Activity 6.5: Running the Backend Server
# Activity 6.6: Testing Backend Using Swagger UI
#
# ── Folder Structure ──────────────────────────────────────
# anxiety_detector_backend/
# ├── main.py              ← This file
# ├── anxiety_model/       ← Trained BERT model folder
# │   ├── config.json
# │   ├── pytorch_model.bin
# │   ├── tokenizer.json
# │   └── vocab.txt
# └── requirements.txt
#
# ── Install dependencies ──────────────────────────────────
# pip install fastapi uvicorn transformers torch pydantic
#
# ── Run the server ────────────────────────────────────────
# uvicorn main:app --reload --host 0.0.0.0 --port 8000
# ============================================================

# -------------------------------------------------------
# Activity 6.1: Selecting FastAPI for Backend Development
# -------------------------------------------------------
# FastAPI is selected because:
#   ✅ High performance (Starlette + Pydantic)
#   ✅ Auto-generates Swagger UI at /docs
#   ✅ Native async support for concurrent requests
#   ✅ Type-safe request/response with Pydantic models
#   ✅ Lightweight and easy to deploy

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import Dict, Optional
import torch
import numpy as np
from transformers import BertTokenizer, BertForSequenceClassification
import os
import logging
import time

# -------------------------------------------------------
# Logging Configuration
# -------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s"
)
logger = logging.getLogger(__name__)

# -------------------------------------------------------
# FastAPI App Initialization
# -------------------------------------------------------
app = FastAPI(
    title="Exam Anxiety Detector API",
    description=(
        "AI-powered API to classify exam-related anxiety from student text. "
        "Predicts Low, Moderate, or High anxiety levels using a BERT model. "
        "⚠️ This is a supportive tool, NOT a clinical diagnosis."
    ),
    version="1.0.0",
    docs_url="/docs",        # Swagger UI
    redoc_url="/redoc"       # ReDoc UI
)

# CORS: Allow Streamlit frontend to call the API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],     # In production, restrict to your domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# -------------------------------------------------------
# Activity 6.2: Loading the Trained BERT Model
# -------------------------------------------------------
MODEL_PATH = os.getenv("MODEL_PATH", "anxiety_model")
MAX_LEN    = 128
NUM_LABELS = 3
device     = torch.device("cuda" if torch.cuda.is_available() else "cpu")

logger.info(f"Loading model from: {MODEL_PATH}")
logger.info(f"Device: {device}")

try:
    tokenizer = BertTokenizer.from_pretrained(MODEL_PATH)
    model     = BertForSequenceClassification.from_pretrained(MODEL_PATH)
    model.to(device)
    model.eval()  # Inference mode: disables dropout
    logger.info("✅ BERT model loaded and set to inference mode.")
except Exception as e:
    logger.warning(f"Model load failed: {e}. Loading base model for demo.")
    tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")
    model     = BertForSequenceClassification.from_pretrained(
                    "bert-base-uncased", num_labels=NUM_LABELS)
    model.to(device)
    model.eval()

# -------------------------------------------------------
# Label Maps & Tips
# -------------------------------------------------------
LABEL_MAP = {
    0: "Low Anxiety",
    1: "Moderate Anxiety",
    2: "High Anxiety"
}

EMOJI_MAP = {
    0: "😊",
    1: "😟",
    2: "😰"
}

TIPS_MAP = {
    0: [
        "Great! You seem calm and prepared. Keep up the good work!",
        "Stay consistent with your study plan.",
        "Get adequate sleep before the exam."
    ],
    1: [
        "Try deep breathing: inhale 4s, hold 4s, exhale 4s.",
        "Take short breaks every 45 minutes while studying.",
        "Talk to a friend or teacher if stress increases.",
        "Light exercise like a 10-minute walk can help."
    ],
    2: [
        "Please consider speaking with a school counselor or trusted adult.",
        "Practice mindfulness or meditation for 10 minutes.",
        "Break your study material into small, manageable chunks.",
        "Remember: one exam does not define your worth.",
        "Reach out for support — you are not alone."
    ]
}

# -------------------------------------------------------
# Activity 6.3: Defining Request & Response Schema
# -------------------------------------------------------
class PredictionRequest(BaseModel):
    text: str = Field(
        ...,
        min_length=5,
        max_length=1000,
        description="Student's exam-related thought or reflection",
        example="I can't sleep, I'm so worried about failing the exam tomorrow."
    )

class ProbabilityScores(BaseModel):
    low_anxiety:      float = Field(..., description="Probability for Low Anxiety (%)")
    moderate_anxiety: float = Field(..., description="Probability for Moderate Anxiety (%)")
    high_anxiety:     float = Field(..., description="Probability for High Anxiety (%)")

class PredictionResponse(BaseModel):
    text:              str
    anxiety_level:     str = Field(..., description="Predicted anxiety category")
    numerical_label:   int = Field(..., description="0=Low, 1=Moderate, 2=High")
    emoji:             str
    confidence:        float = Field(..., description="Confidence of prediction (%)")
    probabilities:     ProbabilityScores
    tips:              list
    inference_time_ms: float
    disclaimer:        str = "This is a supportive tool and NOT a clinical diagnosis."

# -------------------------------------------------------
# Activity 6.4: Implementing the Prediction Endpoint
# -------------------------------------------------------
def run_inference(text: str):
    """Tokenize text and run BERT inference."""
    encoding = tokenizer.encode_plus(
        text,
        add_special_tokens=True,
        max_length=MAX_LEN,
        padding='max_length',
        truncation=True,
        return_attention_mask=True,
        return_tensors='pt'
    )
    input_ids      = encoding['input_ids'].to(device)
    attention_mask = encoding['attention_mask'].to(device)

    with torch.no_grad():
        outputs = model(input_ids=input_ids, attention_mask=attention_mask)

    probs      = torch.softmax(outputs.logits, dim=1).cpu().numpy()[0]
    pred_label = int(np.argmax(probs))
    return pred_label, probs


@app.post(
    "/predict",
    response_model=PredictionResponse,
    summary="Predict Exam Anxiety Level",
    tags=["Prediction"]
)
async def predict_anxiety(request: PredictionRequest):
    """
    Analyse student text and predict exam anxiety level.

    - **Low Anxiety (0)**: Calm and well-prepared
    - **Moderate Anxiety (1)**: Manageable stress
    - **High Anxiety (2)**: Severe stress requiring attention
    """
    if not request.text.strip():
        raise HTTPException(status_code=400, detail="Text cannot be empty.")

    start_time = time.time()

    try:
        pred_label, probs = run_inference(request.text)
    except Exception as e:
        logger.error(f"Inference error: {e}")
        raise HTTPException(status_code=500, detail=f"Model inference failed: {str(e)}")

    elapsed_ms = (time.time() - start_time) * 1000

    logger.info(
        f"Prediction: '{request.text[:40]}...' → "
        f"{LABEL_MAP[pred_label]} ({probs[pred_label]*100:.1f}%)"
    )

    return PredictionResponse(
        text=request.text,
        anxiety_level=LABEL_MAP[pred_label],
        numerical_label=pred_label,
        emoji=EMOJI_MAP[pred_label],
        confidence=round(float(probs[pred_label]) * 100, 2),
        probabilities=ProbabilityScores(
            low_anxiety=round(float(probs[0]) * 100, 2),
            moderate_anxiety=round(float(probs[1]) * 100, 2),
            high_anxiety=round(float(probs[2]) * 100, 2),
        ),
        tips=TIPS_MAP[pred_label],
        inference_time_ms=round(elapsed_ms, 2),
        disclaimer="This is a supportive tool and NOT a clinical diagnosis."
    )


@app.get("/health", summary="Health Check", tags=["System"])
async def health_check():
    """Returns API health status and model info."""
    return {
        "status": "healthy",
        "model": "bert-base-uncased (fine-tuned)",
        "device": str(device),
        "num_labels": NUM_LABELS,
        "max_len": MAX_LEN,
        "labels": LABEL_MAP
    }


@app.get("/", summary="Root", tags=["System"])
async def root():
    """Welcome endpoint."""
    return {
        "message": "Exam Anxiety Detector API is running.",
        "docs": "/docs",
        "health": "/health",
        "predict": "POST /predict"
    }


# -------------------------------------------------------
# Activity 6.5: Running the Backend Server
# -------------------------------------------------------
# Run from terminal:
#   uvicorn main:app --reload --host 0.0.0.0 --port 8000
#
# Or programmatically (for testing):
if __name__ == "__main__":
    import uvicorn
    print("\n" + "=" * 60)
    print("  Exam Anxiety Detector — FastAPI Backend")
    print("=" * 60)
    print("  Swagger UI : http://localhost:8000/docs")
    print("  ReDoc UI   : http://localhost:8000/redoc")
    print("  Health     : http://localhost:8000/health")
    print("  Predict    : POST http://localhost:8000/predict")
    print("=" * 60 + "\n")
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)


# -------------------------------------------------------
# Activity 6.6: Testing Backend Using Swagger UI
# -------------------------------------------------------
# 1. Start server: uvicorn main:app --reload
# 2. Open browser: http://localhost:8000/docs
# 3. Click POST /predict → Try it out
# 4. Enter sample JSON:
#    { "text": "I'm terrified about the exam tomorrow and can't focus." }
# 5. Click Execute and view the structured response.
#
# OR test with curl:
# curl -X POST "http://localhost:8000/predict" \
#      -H "Content-Type: application/json" \
#      -d '{"text": "I am so scared I will fail the exam."}'
