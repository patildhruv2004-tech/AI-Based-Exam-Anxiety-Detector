# ============================================================
# MILESTONE 2: Dataset Collection and Exploratory Data Analysis
# AI-Based Exam Anxiety Detector
# ============================================================

# Activity 2.1: Dataset Selection
# Activity 2.2: Dataset Loading
# Activity 2.3: Understanding Dataset Structure
# Activity 2.4: Checking Missing Values
# Activity 2.5: Class Distribution Analysis
# Activity 2.6: Dataset Suitability Assessment

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from collections import Counter
import warnings
warnings.filterwarnings('ignore')

# -------------------------------------------------------
# Activity 2.1: Dataset Selection
# -------------------------------------------------------
print("=" * 60)
print("ACTIVITY 2.1: Dataset Selection")
print("=" * 60)

# We use the 'Stress Annotated Dataset' or a custom anxiety-labeled
# student text dataset. For this project, we simulate a representative
# dataset based on student feedback text and mapped anxiety labels.
#
# Dataset options:
#   - Student Feedback Dataset (Kaggle)
#   - SemEval Emotion Dataset
#   - Custom labelled student reflections
#
# Here we create a representative sample dataset for demonstration.

print("Dataset Selected: Student Exam Anxiety Text Dataset")
print("Source: Custom / Kaggle Student Feedback Datasets")
print("Format: CSV with 'text' and 'label' columns")

# -------------------------------------------------------
# Activity 2.2: Dataset Loading
# -------------------------------------------------------
print("\n" + "=" * 60)
print("ACTIVITY 2.2: Dataset Loading")
print("=" * 60)

# Simulated dataset representing student exam-related thoughts
data = {
    "text": [
        "I feel very calm and prepared for tomorrow's exam.",
        "I have studied well and I am confident about the test.",
        "Feeling okay, a little nervous but manageable.",
        "I am slightly worried about a few topics but overall fine.",
        "I can't sleep, my heart is racing, and I'm terrified of failing.",
        "I am completely overwhelmed, I feel like I will fail everything.",
        "Just a normal exam, I think I'll do fine.",
        "I studied hard, feeling relaxed and ready.",
        "A bit anxious but nothing I can't handle.",
        "Moderate stress levels, manageable with some breathing exercises.",
        "I am panicking, I haven't studied and the exam is tomorrow.",
        "So stressed, my hands are shaking and I can't focus at all.",
        "I feel confident and well-prepared for this exam.",
        "Slight nervousness, but I know the material.",
        "Extremely anxious, I feel like I'm going to blank out during the exam.",
        "I am terrified, my mind goes blank whenever I think about it.",
        "Feeling neutral, prepared enough for the exam.",
        "A little tension but nothing unusual before exams.",
        "Dread and fear — I haven't covered all the syllabus.",
        "Completely calm, I've revised everything thoroughly.",
    ],
    "label": [
        "low", "low", "moderate", "moderate",
        "high", "high", "low", "low",
        "moderate", "moderate", "high", "high",
        "low", "low", "high", "high",
        "low", "moderate", "high", "low"
    ]
}

df = pd.DataFrame(data)

# Optionally load from CSV:
# df = pd.read_csv("student_anxiety_dataset.csv")

print(f"Dataset loaded successfully.")
print(f"Total records: {len(df)}")
print(f"\nFirst 5 rows:")
print(df.head())

# -------------------------------------------------------
# Activity 2.3: Understanding Dataset Structure
# -------------------------------------------------------
print("\n" + "=" * 60)
print("ACTIVITY 2.3: Understanding Dataset Structure")
print("=" * 60)

print(f"\nShape: {df.shape}")
print(f"\nColumn Names: {list(df.columns)}")
print(f"\nData Types:\n{df.dtypes}")
print(f"\nDataset Info:")
df.info()

print(f"\nSample Text Entries:")
for i, row in df.head(3).iterrows():
    print(f"  [{row['label'].upper()}] {row['text']}")

# -------------------------------------------------------
# Activity 2.4: Checking Missing Values
# -------------------------------------------------------
print("\n" + "=" * 60)
print("ACTIVITY 2.4: Checking Missing Values")
print("=" * 60)

missing = df.isnull().sum()
print(f"\nMissing Values per Column:\n{missing}")

missing_pct = (df.isnull().sum() / len(df)) * 100
print(f"\nMissing Percentage:\n{missing_pct}")

if missing.sum() == 0:
    print("\n✅ No missing values found in the dataset.")
else:
    print(f"\n⚠️ Found {missing.sum()} missing values. Will handle in Milestone 3.")

# Check for empty strings
empty_texts = df[df['text'].str.strip() == ''].shape[0]
print(f"\nEmpty text entries: {empty_texts}")

# -------------------------------------------------------
# Activity 2.5: Class Distribution Analysis
# -------------------------------------------------------
print("\n" + "=" * 60)
print("ACTIVITY 2.5: Class Distribution Analysis")
print("=" * 60)

label_counts = df['label'].value_counts()
print(f"\nClass Distribution:\n{label_counts}")

label_pct = df['label'].value_counts(normalize=True) * 100
print(f"\nClass Percentages:\n{label_pct.round(2)}")

# Plot class distribution
fig, axes = plt.subplots(1, 2, figsize=(12, 4))

# Bar chart
axes[0].bar(label_counts.index, label_counts.values,
            color=['#4CAF50', '#FF9800', '#F44336'], edgecolor='black')
axes[0].set_title('Anxiety Class Distribution', fontsize=13, fontweight='bold')
axes[0].set_xlabel('Anxiety Level')
axes[0].set_ylabel('Count')
for i, v in enumerate(label_counts.values):
    axes[0].text(i, v + 0.1, str(v), ha='center', fontweight='bold')

# Pie chart
axes[1].pie(label_counts.values, labels=label_counts.index, autopct='%1.1f%%',
            colors=['#4CAF50', '#FF9800', '#F44336'], startangle=90)
axes[1].set_title('Anxiety Level Distribution (%)', fontsize=13, fontweight='bold')

plt.tight_layout()
plt.savefig("milestone2_class_distribution.png", dpi=150, bbox_inches='tight')
print("\n📊 Class distribution plot saved as 'milestone2_class_distribution.png'")
plt.show()

# Text length analysis
df['text_length'] = df['text'].apply(len)
df['word_count'] = df['text'].apply(lambda x: len(x.split()))

print(f"\nText Length Statistics:")
print(df.groupby('label')[['text_length', 'word_count']].describe().round(2))

# -------------------------------------------------------
# Activity 2.6: Dataset Suitability Assessment
# -------------------------------------------------------
print("\n" + "=" * 60)
print("ACTIVITY 2.6: Dataset Suitability Assessment")
print("=" * 60)

print("""
📋 Dataset Suitability Report:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ Task Alignment   : Text data directly related to exam anxiety
✅ Label Quality    : Clear 3-class labels (Low/Moderate/High)
✅ Text Format      : Short to medium-length student reflections
✅ Missing Values   : None detected
✅ Class Balance    : Reasonably balanced across 3 classes
✅ BERT Compatible  : Text length suitable for BERT tokenization
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📌 Recommendation   : Dataset is SUITABLE for BERT-based
                       anxiety classification.
""")

print("✅ Milestone 2 Complete: EDA Finished Successfully.")
