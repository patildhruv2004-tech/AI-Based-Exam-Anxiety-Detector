# ============================================================
# MILESTONE 4: BERT Model Selection & Training (Google Colab)
# AI-Based Exam Anxiety Detector
# ============================================================
# ⚠️  Run this file in Google Colab with GPU enabled.
#     Runtime → Change runtime type → GPU (T4 recommended)
# ============================================================

# Activity 4.1: Selection of BERT Model in Google Colab
# Activity 4.2: Uploading Project Code to Google Colab
# Activity 4.3: Environment Setup in Google Colab
# Activity 4.4: Tokenization Using BERT Tokenizer
# Activity 4.5: Model Training Process
# Activity 4.6: Model Evaluation and Saving the Trained Model

# -------------------------------------------------------
# Activity 4.1: Selection of BERT Model
# -------------------------------------------------------
# Model: bert-base-uncased (Hugging Face)
# Why:  - Handles lowercase English text (student reflections)
#       - 12 transformer layers, 110M parameters
#       - Pre-trained on BookCorpus + Wikipedia
#       - BertForSequenceClassification for 3-class output

# -------------------------------------------------------
# Activity 4.2: Uploading Project Code to Google Colab
# -------------------------------------------------------
# Steps in Colab:
#   1. Open Google Colab → New Notebook
#   2. Upload this file via Files panel or:
#      from google.colab import files
#      files.upload()
#   3. Alternatively, mount Google Drive:
#      from google.colab import drive
#      drive.mount('/content/drive')

# -------------------------------------------------------
# Activity 4.3: Environment Setup in Google Colab
# -------------------------------------------------------
# Run in a Colab cell:
# !pip install transformers datasets scikit-learn torch --quiet

import pandas as pd
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
from transformers import (
    BertTokenizer,
    BertForSequenceClassification,
    AdamW,
    get_linear_schedule_with_warmup
)
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    accuracy_score
)
import matplotlib.pyplot as plt
import seaborn as sns
import os
import warnings
warnings.filterwarnings('ignore')

# Device configuration
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"🖥️  Device: {device}")
if torch.cuda.is_available():
    print(f"   GPU: {torch.cuda.get_device_name(0)}")

# -------------------------------------------------------
# Load Final Dataset
# -------------------------------------------------------
# In Colab, load from drive or upload CSV
# df = pd.read_csv("/content/drive/MyDrive/final_anxiety_dataset.csv")

# Simulated dataset for demonstration
data = {
    "text": [
        "I feel very calm and prepared for tomorrow's exam.",
        "I have studied well and I am confident about the test.",
        "I am slightly worried about a few topics but overall fine.",
        "A bit anxious but nothing I can't handle.",
        "Moderate stress levels, manageable with some breathing exercises.",
        "A little tension but nothing unusual before exams.",
        "I can't sleep, my heart is racing, and I'm terrified of failing.",
        "I am completely overwhelmed, I feel like I will fail everything.",
        "I am panicking, I haven't studied and the exam is tomorrow.",
        "So stressed, my hands are shaking and I can't focus at all.",
        "Extremely anxious, I feel like I'm going to blank out during the exam.",
        "I am terrified, my mind goes blank whenever I think about it.",
        "Just a normal exam, I think I'll do fine.",
        "I studied hard, feeling relaxed and ready.",
        "I feel confident and well-prepared for this exam.",
        "Slight nervousness, but I know the material.",
        "Feeling neutral, prepared enough for the exam.",
        "Completely calm, I've revised everything thoroughly.",
        "Dread and fear — I haven't covered all the syllabus.",
        "Feeling okay, a little nervous but manageable.",
    ],
    "numerical_label": [0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 0, 0, 0, 0, 0, 0, 2, 1]
}
df = pd.DataFrame(data)

LABEL_MAP = {0: "Low Anxiety", 1: "Moderate Anxiety", 2: "High Anxiety"}
NUM_LABELS = 3
MAX_LEN = 128
BATCH_SIZE = 8
EPOCHS = 3
LEARNING_RATE = 2e-5
MODEL_NAME = "bert-base-uncased"

# -------------------------------------------------------
# Activity 4.4: Tokenization Using BERT Tokenizer
# -------------------------------------------------------
print("\n" + "=" * 60)
print("ACTIVITY 4.4: Tokenization Using BERT Tokenizer")
print("=" * 60)

tokenizer = BertTokenizer.from_pretrained(MODEL_NAME)
print(f"✅ Tokenizer loaded: {MODEL_NAME}")

# Test tokenization
sample_text = "I am very anxious about the upcoming exam."
tokens = tokenizer.encode_plus(
    sample_text,
    add_special_tokens=True,
    max_length=MAX_LEN,
    padding='max_length',
    truncation=True,
    return_attention_mask=True,
    return_tensors='pt'
)
print(f"\nSample Tokenization:")
print(f"  Text          : {sample_text}")
print(f"  Input IDs     : {tokens['input_ids'].shape}")
print(f"  Attention Mask: {tokens['attention_mask'].shape}")
print(f"  Token Count   : {tokens['attention_mask'].sum().item()}")

# -------------------------------------------------------
# Custom Dataset Class
# -------------------------------------------------------
class AnxietyDataset(Dataset):
    def __init__(self, texts, labels, tokenizer, max_len):
        self.texts = texts
        self.labels = labels
        self.tokenizer = tokenizer
        self.max_len = max_len

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, idx):
        encoding = self.tokenizer.encode_plus(
            self.texts[idx],
            add_special_tokens=True,
            max_length=self.max_len,
            padding='max_length',
            truncation=True,
            return_attention_mask=True,
            return_tensors='pt'
        )
        return {
            'input_ids': encoding['input_ids'].flatten(),
            'attention_mask': encoding['attention_mask'].flatten(),
            'labels': torch.tensor(self.labels[idx], dtype=torch.long)
        }

# Train/Validation Split
X_train, X_val, y_train, y_val = train_test_split(
    df['text'].tolist(),
    df['numerical_label'].tolist(),
    test_size=0.2,
    random_state=42,
    stratify=df['numerical_label'].tolist()
)
print(f"\nTrain samples: {len(X_train)} | Val samples: {len(X_val)}")

train_dataset = AnxietyDataset(X_train, y_train, tokenizer, MAX_LEN)
val_dataset   = AnxietyDataset(X_val,   y_val,   tokenizer, MAX_LEN)

train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)
val_loader   = DataLoader(val_dataset,   batch_size=BATCH_SIZE)

# -------------------------------------------------------
# Activity 4.5: Model Training Process
# -------------------------------------------------------
print("\n" + "=" * 60)
print("ACTIVITY 4.5: Model Training Process")
print("=" * 60)

model = BertForSequenceClassification.from_pretrained(
    MODEL_NAME,
    num_labels=NUM_LABELS,
    output_attentions=False,
    output_hidden_states=False
)
model.to(device)
print(f"✅ Model loaded: {MODEL_NAME} with {NUM_LABELS} output classes")

optimizer = AdamW(model.parameters(), lr=LEARNING_RATE, eps=1e-8)
total_steps = len(train_loader) * EPOCHS
scheduler = get_linear_schedule_with_warmup(
    optimizer,
    num_warmup_steps=int(0.1 * total_steps),
    num_training_steps=total_steps
)

train_losses, val_accuracies = [], []

def train_epoch(model, loader, optimizer, scheduler, device):
    model.train()
    total_loss = 0
    for batch in loader:
        optimizer.zero_grad()
        input_ids      = batch['input_ids'].to(device)
        attention_mask = batch['attention_mask'].to(device)
        labels         = batch['labels'].to(device)
        outputs = model(input_ids=input_ids, attention_mask=attention_mask, labels=labels)
        loss = outputs.loss
        total_loss += loss.item()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()
        scheduler.step()
    return total_loss / len(loader)

def eval_epoch(model, loader, device):
    model.eval()
    preds_all, labels_all = [], []
    with torch.no_grad():
        for batch in loader:
            input_ids      = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            labels         = batch['labels'].to(device)
            outputs = model(input_ids=input_ids, attention_mask=attention_mask)
            preds = torch.argmax(outputs.logits, dim=1)
            preds_all.extend(preds.cpu().numpy())
            labels_all.extend(labels.cpu().numpy())
    return accuracy_score(labels_all, preds_all), preds_all, labels_all

print(f"\nStarting training for {EPOCHS} epochs...")
print("-" * 50)

for epoch in range(EPOCHS):
    train_loss = train_epoch(model, train_loader, optimizer, scheduler, device)
    val_acc, _, _ = eval_epoch(model, val_loader, device)
    train_losses.append(train_loss)
    val_accuracies.append(val_acc)
    print(f"  Epoch {epoch+1}/{EPOCHS} | Loss: {train_loss:.4f} | Val Acc: {val_acc:.4f}")

# -------------------------------------------------------
# Activity 4.6: Model Evaluation and Saving
# -------------------------------------------------------
print("\n" + "=" * 60)
print("ACTIVITY 4.6: Model Evaluation and Saving")
print("=" * 60)

_, final_preds, final_labels = eval_epoch(model, val_loader, device)

print("\n📊 Classification Report:")
print(classification_report(
    final_labels, final_preds,
    target_names=["Low Anxiety", "Moderate Anxiety", "High Anxiety"]
))

# Confusion matrix
cm = confusion_matrix(final_labels, final_preds)
plt.figure(figsize=(6, 5))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
            xticklabels=["Low", "Moderate", "High"],
            yticklabels=["Low", "Moderate", "High"])
plt.title("Confusion Matrix - Validation Set", fontweight='bold')
plt.ylabel("Actual")
plt.xlabel("Predicted")
plt.tight_layout()
plt.savefig("milestone4_confusion_matrix.png", dpi=150, bbox_inches='tight')
print("📊 Confusion matrix saved as 'milestone4_confusion_matrix.png'")
plt.show()

# Training curve
fig, axes = plt.subplots(1, 2, figsize=(11, 4))
axes[0].plot(range(1, EPOCHS+1), train_losses, 'b-o', label='Train Loss')
axes[0].set_title("Training Loss"); axes[0].set_xlabel("Epoch"); axes[0].set_ylabel("Loss")
axes[0].legend()
axes[1].plot(range(1, EPOCHS+1), val_accuracies, 'g-o', label='Val Accuracy')
axes[1].set_title("Validation Accuracy"); axes[1].set_xlabel("Epoch"); axes[1].set_ylabel("Accuracy")
axes[1].legend()
plt.tight_layout()
plt.savefig("milestone4_training_curve.png", dpi=150, bbox_inches='tight')
print("📊 Training curve saved as 'milestone4_training_curve.png'")
plt.show()

# Save model and tokenizer
os.makedirs("anxiety_model", exist_ok=True)
model.save_pretrained("anxiety_model")
tokenizer.save_pretrained("anxiety_model")
print("\n💾 Model saved to 'anxiety_model/' directory")
print("   Files: config.json, pytorch_model.bin, vocab.txt, tokenizer.json")

# In Colab: download model zip
# import shutil
# shutil.make_archive("anxiety_model", 'zip', "anxiety_model")
# files.download("anxiety_model.zip")

print("\n✅ Milestone 4 Complete: BERT Model Trained and Saved.")
