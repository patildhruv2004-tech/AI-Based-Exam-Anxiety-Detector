# ============================================================
# MILESTONE 7: Frontend Development for Anxiety Detection
# AI-Based Exam Anxiety Detector
# ============================================================
# File: app.py  (Streamlit Frontend)
#
# Activity 7.1: Selecting Streamlit for Frontend Development
# Activity 7.2: Connecting Frontend to Backend API
#
# ── Folder Structure ──────────────────────────────────────
# anxiety_detector_frontend/
# └── app.py      ← This file
#
# ── Install dependencies ──────────────────────────────────
# pip install streamlit requests plotly
#
# ── Run ──────────────────────────────────────────────────
# streamlit run app.py
#
# ── Ensure FastAPI backend (Milestone 6) is running ───────
# uvicorn main:app --reload --host 0.0.0.0 --port 8000
# ============================================================

# -------------------------------------------------------
# Activity 7.1: Selecting Streamlit for Frontend Development
# -------------------------------------------------------
# Streamlit is selected because:
#   ✅ Pure Python — no HTML/CSS/JS required
#   ✅ Rapid UI development with rich widgets
#   ✅ Native support for charts, progress bars, columns
#   ✅ Easy deployment to Streamlit Community Cloud
#   ✅ Ideal for ML/AI demo applications

import streamlit as st
import requests
import plotly.graph_objects as go
import time

# -------------------------------------------------------
# Page Configuration
# -------------------------------------------------------
st.set_page_config(
    page_title="Exam Anxiety Detector",
    page_icon="🎓",
    layout="centered",
    initial_sidebar_state="expanded"
)

# -------------------------------------------------------
# Activity 7.2: Connecting Frontend to Backend API
# -------------------------------------------------------
API_URL = "http://localhost:8000"

# ── Custom CSS ──────────────────────────────────────────
st.markdown("""
<style>
    .main-title {
        font-size: 2.4em;
        font-weight: 800;
        text-align: center;
        color: #2C3E50;
        margin-bottom: 0.1em;
    }
    .subtitle {
        font-size: 1.1em;
        text-align: center;
        color: #7F8C8D;
        margin-bottom: 1.5em;
    }
    .result-card {
        background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        padding: 1.5em;
        border-radius: 16px;
        text-align: center;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }
    .anxiety-low      { color: #27AE60; font-size: 2em; font-weight: 800; }
    .anxiety-moderate { color: #E67E22; font-size: 2em; font-weight: 800; }
    .anxiety-high     { color: #E74C3C; font-size: 2em; font-weight: 800; }
    .tip-box {
        background: #EBF5FB;
        border-left: 4px solid #3498DB;
        padding: 0.8em 1em;
        border-radius: 6px;
        margin: 0.4em 0;
    }
    .disclaimer {
        background: #FEF9E7;
        border: 1px solid #F39C12;
        padding: 0.7em 1em;
        border-radius: 8px;
        font-size: 0.85em;
        color: #784212;
        margin-top: 1em;
    }
    .history-item {
        background: #F8F9FA;
        border-radius: 8px;
        padding: 0.6em 1em;
        margin: 0.3em 0;
        border-left: 4px solid #AEB6BF;
    }
</style>
""", unsafe_allow_html=True)

# ── Sidebar ────────────────────────────────────────────
with st.sidebar:
    st.image("https://img.icons8.com/fluency/96/graduation-cap.png", width=80)
    st.markdown("### ⚙️ Settings")
    api_host = st.text_input("API Host", value="http://localhost:8000")
    st.markdown("---")
    st.markdown("### 📘 About")
    st.markdown("""
    This tool uses a **BERT-based AI model** to analyse student
    text and detect exam anxiety levels:
    
    - 😊 **Low**: Calm & prepared
    - 😟 **Moderate**: Manageable stress
    - 😰 **High**: Needs attention
    
    ---
    ⚠️ **Not a clinical tool.** For support, speak to a counselor.
    """)
    st.markdown("---")
    # Backend health check
    if st.button("🔍 Check API Status"):
        try:
            resp = requests.get(f"{api_host}/health", timeout=3)
            if resp.status_code == 200:
                st.success("✅ API is online")
            else:
                st.error(f"❌ API returned {resp.status_code}")
        except Exception:
            st.error("❌ Cannot reach API server")

# ── Header ────────────────────────────────────────────
st.markdown('<div class="main-title">🎓 Exam Anxiety Detector</div>', unsafe_allow_html=True)
st.markdown('<div class="subtitle">AI-powered mental wellness support for students</div>',
            unsafe_allow_html=True)

# ── Tabs ──────────────────────────────────────────────
tab1, tab2, tab3 = st.tabs(["🔍 Anxiety Check", "📊 Batch Analysis", "📜 History"])

# Session state for history
if "history" not in st.session_state:
    st.session_state.history = []

# ─────────────────────────────────────────────────────
# TAB 1: Single Anxiety Check
# ─────────────────────────────────────────────────────
with tab1:
    st.markdown("#### 💬 Share your thoughts about the upcoming exam")
    st.caption("Type how you're feeling. The AI will assess your anxiety level.")

    user_text = st.text_area(
        "Your thoughts:",
        placeholder=(
            "e.g., I haven't slept well, my heart is racing and I'm scared of failing..."
        ),
        height=130,
        max_chars=1000
    )

    col_btn, col_clear = st.columns([3, 1])
    with col_btn:
        analyse_btn = st.button("🔍 Analyse My Anxiety", use_container_width=True, type="primary")
    with col_clear:
        if st.button("🗑️ Clear", use_container_width=True):
            st.rerun()

    if analyse_btn:
        if not user_text.strip():
            st.warning("⚠️ Please enter some text before analysing.")
        elif len(user_text.strip()) < 5:
            st.warning("⚠️ Please enter a more detailed description (at least 5 characters).")
        else:
            with st.spinner("🤖 Analysing your text with BERT..."):
                try:
                    # ── Activity 7.2: API Call ───────────────────────
                    response = requests.post(
                        f"{api_host}/predict",
                        json={"text": user_text.strip()},
                        timeout=15
                    )
                    response.raise_for_status()
                    result = response.json()

                    anxiety = result["anxiety_level"]
                    emoji   = result["emoji"]
                    conf    = result["confidence"]
                    probs   = result["probabilities"]
                    tips    = result["tips"]
                    label   = result["numerical_label"]
                    ms      = result["inference_time_ms"]

                    # CSS class for color
                    cls_map  = {0: "anxiety-low", 1: "anxiety-moderate", 2: "anxiety-high"}
                    bg_map   = {0: "#EAFAF1", 1: "#FEF5E7", 2: "#FDEDEC"}
                    bdr_map  = {0: "#27AE60",  1: "#E67E22",  2: "#E74C3C"}

                    # ── Result Card ──────────────────────────────────
                    st.markdown(f"""
                    <div class="result-card" style="background:{bg_map[label]};
                         border:2px solid {bdr_map[label]};">
                        <div style="font-size:3em;">{emoji}</div>
                        <div class="{cls_map[label]}">{anxiety}</div>
                        <div style="font-size:1em; color:#555; margin-top:0.3em;">
                            Confidence: <strong>{conf}%</strong>
                            &nbsp;|&nbsp; Inference: {ms}ms
                        </div>
                    </div>
                    """, unsafe_allow_html=True)

                    st.markdown("<br>", unsafe_allow_html=True)

                    # ── Probability Gauge Chart ──────────────────────
                    st.markdown("##### 📊 Anxiety Probability Breakdown")
                    fig = go.Figure(go.Bar(
                        x=["Low Anxiety 😊", "Moderate Anxiety 😟", "High Anxiety 😰"],
                        y=[probs["low_anxiety"],
                           probs["moderate_anxiety"],
                           probs["high_anxiety"]],
                        marker_color=["#27AE60", "#E67E22", "#E74C3C"],
                        text=[f"{v:.1f}%" for v in [probs["low_anxiety"],
                              probs["moderate_anxiety"], probs["high_anxiety"]]],
                        textposition="outside"
                    ))
                    fig.update_layout(
                        yaxis=dict(title="Probability (%)", range=[0, 110]),
                        xaxis=dict(title="Anxiety Level"),
                        plot_bgcolor="rgba(0,0,0,0)",
                        paper_bgcolor="rgba(0,0,0,0)",
                        margin=dict(t=20, b=20),
                        height=300
                    )
                    st.plotly_chart(fig, use_container_width=True)

                    # ── Tips ────────────────────────────────────────
                    st.markdown("##### 💡 Personalised Recommendations")
                    for tip in tips:
                        st.markdown(
                            f'<div class="tip-box">✅ {tip}</div>',
                            unsafe_allow_html=True
                        )

                    # ── Disclaimer ──────────────────────────────────
                    st.markdown(
                        '<div class="disclaimer">'
                        '⚠️ <strong>Disclaimer:</strong> This tool is for awareness and support only. '
                        'It is NOT a clinical diagnosis. If you are experiencing severe distress, '
                        'please consult a qualified mental health professional or school counselor.'
                        '</div>',
                        unsafe_allow_html=True
                    )

                    # ── Save to History ──────────────────────────────
                    st.session_state.history.append({
                        "text":    user_text.strip()[:60] + "...",
                        "level":   anxiety,
                        "emoji":   emoji,
                        "conf":    conf
                    })

                except requests.exceptions.ConnectionError:
                    st.error(
                        "❌ Cannot connect to the API server.\n\n"
                        "Please ensure the FastAPI backend is running:\n"
                        "`uvicorn main:app --reload --port 8000`"
                    )
                except requests.exceptions.Timeout:
                    st.error("⏱️ Request timed out. The model may be loading. Please try again.")
                except requests.exceptions.HTTPError as e:
                    st.error(f"❌ API Error: {e.response.status_code} — {e.response.text}")
                except Exception as e:
                    st.error(f"❌ Unexpected error: {str(e)}")

# ─────────────────────────────────────────────────────
# TAB 2: Batch Analysis
# ─────────────────────────────────────────────────────
with tab2:
    st.markdown("#### 📋 Batch Anxiety Analysis")
    st.caption("Enter multiple student texts (one per line) for bulk analysis.")

    batch_text = st.text_area(
        "Enter texts (one per line):",
        placeholder=(
            "I feel calm and ready for the exam.\n"
            "I am so scared, I haven't studied enough.\n"
            "A bit nervous but manageable."
        ),
        height=180
    )

    if st.button("🔍 Analyse All", type="primary"):
        texts = [t.strip() for t in batch_text.strip().split("\n") if t.strip()]
        if not texts:
            st.warning("Please enter at least one text.")
        else:
            results = []
            progress = st.progress(0)
            for i, text in enumerate(texts):
                try:
                    resp = requests.post(
                        f"{api_host}/predict",
                        json={"text": text}, timeout=15
                    )
                    resp.raise_for_status()
                    r = resp.json()
                    results.append({
                        "Text":           text[:60] + ("..." if len(text) > 60 else ""),
                        "Anxiety Level":  r["anxiety_level"],
                        "Emoji":          r["emoji"],
                        "Confidence (%)": r["confidence"]
                    })
                except Exception:
                    results.append({
                        "Text":           text[:60],
                        "Anxiety Level":  "Error",
                        "Emoji":          "❓",
                        "Confidence (%)": 0
                    })
                progress.progress((i + 1) / len(texts))

            import pandas as pd
            df = pd.DataFrame(results)
            st.dataframe(df, use_container_width=True)

            # Summary pie chart
            counts = df["Anxiety Level"].value_counts()
            fig_pie = go.Figure(go.Pie(
                labels=counts.index,
                values=counts.values,
                marker_colors=["#27AE60", "#E67E22", "#E74C3C"],
                hole=0.3
            ))
            fig_pie.update_layout(
                title="Anxiety Distribution (Batch)",
                height=320,
                margin=dict(t=40, b=10)
            )
            st.plotly_chart(fig_pie, use_container_width=True)

# ─────────────────────────────────────────────────────
# TAB 3: History
# ─────────────────────────────────────────────────────
with tab3:
    st.markdown("#### 📜 Prediction History (This Session)")
    if not st.session_state.history:
        st.info("No predictions made yet. Use the Anxiety Check tab to analyse text.")
    else:
        for i, item in enumerate(reversed(st.session_state.history), 1):
            st.markdown(
                f'<div class="history-item">'
                f'<strong>#{i}</strong> {item["emoji"]} <strong>{item["level"]}</strong> '
                f'({item["conf"]}%) — <em>{item["text"]}</em>'
                f'</div>',
                unsafe_allow_html=True
            )
        if st.button("🗑️ Clear History"):
            st.session_state.history = []
            st.rerun()

# ── Footer ────────────────────────────────────────────
st.markdown("---")
st.markdown(
    "<center style='color:#AEB6BF; font-size:0.85em;'>"
    "🎓 Exam Anxiety Detector | BERT-based NLP | Supportive Tool Only"
    "</center>",
    unsafe_allow_html=True
)
