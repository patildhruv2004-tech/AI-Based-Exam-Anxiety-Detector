# ============================================================
# MILESTONE 3: Data Preprocessing & Label Mapping
# AI-Based Exam Anxiety Detector
# ============================================================

# Activity 3.1: Handling Missing Text Data
# Activity 3.2: Understanding Original Labels
# Activity 3.3: Anxiety Level Label Mapping
# Activity 3.4: Creating Numerical Labels
# Activity 3.5: Validation of Label Mapping
# Activity 3.6: Final Dataset Preparation

import pandas as pd
import numpy as np
import re
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')

# -------------------------------------------------------
# Load Dataset (from Milestone 2 or CSV)
# -------------------------------------------------------
data = {
    "text": [
        "I feel very calm and prepared for tomorrow's exam.",
        "I have studied well and I am confident about the test.",
        None,  # Simulated missing value
        "I am slightly worried about a few topics but overall fine.",
        "I can't sleep, my heart is racing, and I'm terrified of failing.",
        "I am completely overwhelmed, I feel like I will fail everything.",
        "",    # Simulated empty string
        "I studied hard, feeling relaxed and ready.",
        "A bit anxious but nothing I can't handle.",
        "Moderate stress levels, manageable with some breathing exercises.",
        "I am panicking, I haven't studied and the exam is tomorrow.",
        "So stressed, my hands are shaking and I can't focus at all.",
        "I feel confident and well-prepared for this exam.",
        "Slight nervousness, but I know the material.",
        "Extremely anxious, I feel like I'm going to blank out during the exam.",
        "I am terrified, my mind goes blank whenever I think about it.",
        "Feeling neutral, prepared enough for the exam.",
        "A little tension but nothing unusual before exams.",
        "Dread and fear — I haven't covered all the syllabus.",
        "Completely calm, I've revised everything thoroughly.",
    ],
    "label": [
        "low", "low", "moderate", "moderate",
        "high", "high", "low", "low",
        "moderate", "moderate", "high", "high",
        "low", "low", "high", "high",
        "low", "moderate", "high", "low"
    ]
}

df = pd.DataFrame(data)
print(f"Original Dataset Shape: {df.shape}")

# -------------------------------------------------------
# Activity 3.1: Handling Missing Text Data
# -------------------------------------------------------
print("\n" + "=" * 60)
print("ACTIVITY 3.1: Handling Missing Text Data")
print("=" * 60)

print(f"\nBefore Cleaning:")
print(f"  Total rows       : {len(df)}")
print(f"  Null texts       : {df['text'].isnull().sum()}")
print(f"  Empty strings    : {(df['text'].str.strip() == '').sum()}")

# Step 1: Replace empty strings with NaN
df['text'] = df['text'].replace('', np.nan)

# Step 2: Drop rows where text is NaN
df.dropna(subset=['text'], inplace=True)
df.reset_index(drop=True, inplace=True)

print(f"\nAfter Cleaning:")
print(f"  Total rows       : {len(df)}")
print(f"  Null texts       : {df['text'].isnull().sum()}")
print("✅ Missing text data handled successfully.")

# -------------------------------------------------------
# Activity 3.2: Understanding Original Labels
# -------------------------------------------------------
print("\n" + "=" * 60)
print("ACTIVITY 3.2: Understanding Original Labels")
print("=" * 60)

print(f"\nUnique Labels Found: {df['label'].unique()}")
print(f"\nLabel Counts:\n{df['label'].value_counts()}")

print("""
Original Label Descriptions:
  'low'      → Student shows minimal anxiety signs
  'moderate' → Student shows noticeable but manageable anxiety
  'high'     → Student shows severe anxiety requiring attention
""")

# -------------------------------------------------------
# Activity 3.3: Anxiety Level Label Mapping
# -------------------------------------------------------
print("\n" + "=" * 60)
print("ACTIVITY 3.3: Anxiety Level Label Mapping")
print("=" * 60)

# Map string labels to standardized anxiety levels
label_mapping = {
    "low": "Low Anxiety",
    "moderate": "Moderate Anxiety",
    "high": "High Anxiety"
}

df['anxiety_level'] = df['label'].map(label_mapping)

print("\nLabel Mapping Applied:")
for k, v in label_mapping.items():
    print(f"  '{k}' → '{v}'")

print(f"\nSample After Mapping:")
print(df[['text', 'label', 'anxiety_level']].head(5))

# -------------------------------------------------------
# Activity 3.4: Creating Numerical Labels
# -------------------------------------------------------
print("\n" + "=" * 60)
print("ACTIVITY 3.4: Creating Numerical Labels")
print("=" * 60)

# Numerical encoding required for model training
numerical_mapping = {
    "Low Anxiety": 0,
    "Moderate Anxiety": 1,
    "High Anxiety": 2
}

df['numerical_label'] = df['anxiety_level'].map(numerical_mapping)

print("\nNumerical Label Mapping:")
for k, v in numerical_mapping.items():
    print(f"  '{k}' → {v}")

print(f"\nSample with Numerical Labels:")
print(df[['text', 'anxiety_level', 'numerical_label']].head(6))

# -------------------------------------------------------
# Activity 3.5: Validation of Label Mapping
# -------------------------------------------------------
print("\n" + "=" * 60)
print("ACTIVITY 3.5: Validation of Label Mapping")
print("=" * 60)

# Check no NaN in mapped columns
print(f"\nNull values in 'anxiety_level'   : {df['anxiety_level'].isnull().sum()}")
print(f"Null values in 'numerical_label' : {df['numerical_label'].isnull().sum()}")

# Validate all expected labels are present
expected_labels = {0, 1, 2}
actual_labels = set(df['numerical_label'].unique())
print(f"\nExpected Labels : {expected_labels}")
print(f"Actual Labels   : {actual_labels}")

if expected_labels == actual_labels:
    print("✅ All labels correctly mapped.")
else:
    print("⚠️ Label mismatch detected. Please review.")

# Cross-tabulation check
print(f"\nCross-Validation Table:")
print(pd.crosstab(df['label'], df['numerical_label']))

# Visualization
fig, ax = plt.subplots(figsize=(7, 4))
colors = ['#4CAF50', '#FF9800', '#F44336']
counts = df['anxiety_level'].value_counts()
counts = counts.reindex(['Low Anxiety', 'Moderate Anxiety', 'High Anxiety'])
bars = ax.bar(counts.index, counts.values, color=colors, edgecolor='black', width=0.5)
ax.set_title("Mapped Anxiety Level Distribution", fontsize=13, fontweight='bold')
ax.set_ylabel("Count")
ax.set_xlabel("Anxiety Level")
for bar, val in zip(bars, counts.values):
    ax.text(bar.get_x() + bar.get_width() / 2, val + 0.1,
            str(val), ha='center', fontweight='bold')
plt.tight_layout()
plt.savefig("milestone3_label_distribution.png", dpi=150, bbox_inches='tight')
print("\n📊 Label distribution plot saved as 'milestone3_label_distribution.png'")
plt.show()

# -------------------------------------------------------
# Activity 3.6: Final Dataset Preparation
# -------------------------------------------------------
print("\n" + "=" * 60)
print("ACTIVITY 3.6: Final Dataset Preparation")
print("=" * 60)

# Text cleaning function
def clean_text(text):
    text = str(text).strip()
    text = re.sub(r'\s+', ' ', text)          # Remove extra spaces
    text = re.sub(r'[^\w\s.,!?\'-]', '', text) # Remove special chars
    return text

df['cleaned_text'] = df['text'].apply(clean_text)

# Final dataset with required columns
final_df = df[['cleaned_text', 'anxiety_level', 'numerical_label']].copy()
final_df.rename(columns={'cleaned_text': 'text'}, inplace=True)

print(f"\nFinal Dataset Shape: {final_df.shape}")
print(f"\nFinal Columns: {list(final_df.columns)}")
print(f"\nFinal Dataset Preview:")
print(final_df.head(8).to_string(index=False))

# Save final dataset
final_df.to_csv("final_anxiety_dataset.csv", index=False)
print("\n💾 Final dataset saved as 'final_anxiety_dataset.csv'")

print(f"""
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📋 Final Dataset Summary:
   Total Samples  : {len(final_df)}
   Classes        : Low (0), Moderate (1), High (2)
   Label Column   : 'numerical_label'
   Text Column    : 'text'
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
""")

print("✅ Milestone 3 Complete: Preprocessing & Label Mapping Done.")
